export const prices_ar = [
  {
    name:"מנוי זמני",
    months:1,
    price:225,
    info:"מנוי חודשי למאנקיס PASS (לא מתחדש)"
  },
  {
    name:"מנוי מקצועי",
    months:3,
    price:330,
    info:"מנוי 3 חודשים למאנקיס PASS  (לא מתחדש)"
  },
  {
    name:"מנוי עסקי/קבוצתי",
    months:12,
    price:1250,
    info:"מנוי 12 חודשים למאנקיס  - 3 מנויים (לא מתחדש)"
  }
  ,
  {
    name:"מנוי טסט טסט",
    months:1,
    price:77,
    info:"טסט"
  }
]

prices_ar[8810] = {
  name:"מנוי קופון מיוחד - לחברי מאנקיס",
  months:3,
  price:250,
  info:"מנוי 3 חודשים למאנקיס PASS  (לא מתחדש)"
}

prices_ar[8410] = {
  name:"מנוי קופון מיוחד - לחברי מאנקיס",
  months:3,
  price:450,
  info:"מנוי 6 חודשים למאנקיס PASS  (לא מתחדש)"
}