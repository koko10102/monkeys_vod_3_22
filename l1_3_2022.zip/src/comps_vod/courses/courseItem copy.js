import React from 'react';
import { Link } from 'react-router-dom';

function CourseItem(props) {
  let item = props.item;
  return (
    <div className="col-md-4 px-2 py-2">
      <div className="box_course text-white h-100" style={{ background: "black" }}>
        <div className="box_pic" style={{ backgroundImage: `url(${item.img_url})` }}></div>
        <h4 className='py-3 px-2'>{item.title}</h4>
        <p className='pb-2 px-2'>
          {item.info}
        </p>
        {/* <Link to={"/player/?course="+item.short_id} >לקורס</Link> */}
        {(item.link_outside.length > 4) ? 
          <a href={item.link_outside} target="_blank">לקורס</a>
        : <Link to={"/player/"+item.short_id} >לקורס</Link>
      }
      </div>

    </div>
  )
}

export default CourseItem