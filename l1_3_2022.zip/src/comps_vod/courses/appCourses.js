import React, { useEffect, useState } from 'react';
import { API_URL, doApiGet } from '../../services/apiService';
import ScrollTop from '../misc/scrollTop';
import CourseItem from './courseItem';

function AppCourses(props) {
  let [list_ar,setList] = useState([])

  useEffect(() => {
    doApi();
  },[]);
  
  const doApi = async() => {
    let url = API_URL+"/courses/";
    let data = await doApiGet(url);
    console.log(data);
    setList(data)
  }
  
  return (
    <div className='container-fluid courses'>
      <ScrollTop />
      <div className='container' style={{minHeight:"80vh"}}>
        <h2 className='display-6 text-center my-5'>
          הקורסים שלנו, לחץ על קורס והתחל לצפות 
          <br/>
          (חלק מהסרטונים פתוחים  למנויי מאנקיס פאסס בלבד)
        </h2>
        <div className="row justify-content-center">
          {list_ar.length == 0 ? <h2 className='text-center'> טוען... </h2>: ""}
          {list_ar.map(item => {
            if(item.position !== 1000){
            return(
              <CourseItem key={item._id} item={item}/>
            )
          }
          })}
        </div>
      </div>
    </div>
  )
}

export default AppCourses