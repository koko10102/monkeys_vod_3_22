import React, { useContext } from 'react';
import { Link } from 'react-router-dom';
import AuthComp from '../authComp';

import { AppContext } from '../context/context';

function WelcomeBack(props) {

  let { info } = useContext(AppContext);
  return (
    <div className='container-fluid welcome_out'>
      <AuthComp />
      <div style={{ backgroundImage: `url(/images/welcome.png)`, minHeight: "85vh" }} className='d-flex align-items-center container welcome' >
        <article className='w-100'>
          <h1 className='my-4 text-center text-md-end'>ברוכים השבים לMONKEYS PASS </h1>
          {info.paid ?
            <div>
              <h2>הינך מתשמש פרימיום </h2>
              <small>* לפרטים נוספים לחץ על החשבון שלי</small>
            </div> : ""}
          <div className="row pb-5">
            <div className="col-md-6">
              <ul>
                <li>
                  סרטונים חדשים כל שבוע/שבועיים למנויים בתשלום
                </li>
                <li>מאפשר חזרה לאותה נקודה בקורס בה הפסקת</li>
                <li>עשרות קורסים ומאות סרטוני הדרכה שתוכל לצפות מכל מקום ומכל מכשיר תומך</li>
                <li>קורסים שמסודרים בדרגת קושי ומידע על ידע מקדים לכל קורס שתמיד תוכל להשלים בקורסים אצלנו</li>
              </ul>
              {!info.paid ?
                <Link to="/premium">
                  <button className='btn btn-info shadow'>הרשם למנוי פרימיום</button>
                </Link>
                : ""
              }
              <Link to="/courses_vod">
                <button className='btn btn-dark me-2 shadow'>לחץ כאן לצפייה בקורסים</button>
              </Link>
            </div>
            <div className="col-md-6"></div>
          </div>
        </article>
      </div>
    </div>
  )
}

export default WelcomeBack