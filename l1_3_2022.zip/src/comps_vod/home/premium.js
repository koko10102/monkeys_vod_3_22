import React, { useContext } from 'react';
import { Link } from 'react-router-dom';

import { AppContext } from '../context/context';
import ScrollTop from '../misc/scrollTop';
import {prices_ar} from "../../data/prices_json"

function Premium(props) {

  let classPrice = "col-md-4 p-3 text-center"
  let { info } = useContext(AppContext);
  console.log(info)
  return (
    <div className='container-fluid welcome_out pricing'>
      <ScrollTop />
      <div style={{ minHeight: "85vh" }} className='d-flex align-items-center container welcome py-4' >
        <article className='w-100'>
          <h1 className='my-4 text-center'>חבילות רכישה ל MONKEYS PASS</h1>
          <div className="row price_list mb-5">
            <article className={classPrice + " order-md-0 order-2"}>
              <div className="box p-2 border my-md-2 ">
                <h2 className='display-4'>זמני</h2>
                <h3 className='display-3 text-info'> {prices_ar[0].price} ₪</h3>
                <h3>מנוי חודשי</h3>
                <ul className='text-end'>
                  <li>כל הסרטונים פתוחים לצפייה</li>
                  <li>בכל שבועיים סרטונים חדשים</li>
                  <li>חוברות לימוד כתובות</li>
                  <li>קבצי קוד מסרטונים נתמכים</li>
                  <li>טוב ללפני מבחן/פרוייקט</li>
                </ul>
                {info.login ? 
                <Link to="/pay/0" className='btn btn-primary my-4'>רכוש כאן</Link>
                : <Link to="/login" className='btn btn-primary my-4'>לרכישה יש להתחבר/להרשם קודם</Link>
                }
              </div>
            </article>

            <article className={classPrice}>
              <div className="box p-2 border">
                <h2 className='display-3'>מקצועי</h2>
                <h3 className='display-2 text-info'> {prices_ar[1].price} ₪</h3>
                <h3>מנוי 3 חודשים - מומלץ</h3>
                <ul className='text-end'>
                  <li>כל הסרטונים פתוחים לצפייה</li>
                  <li>בכל שבועיים סרטונים חדשים</li>
                  <li>חוברות לימוד כתובות</li>
                  <li>קבצי קוד מסרטונים נתמכים</li>
                  <li>חסוך מעל 50% במחיר</li>
                </ul>

                {info.login ? 
                <Link to="/pay/1" className='btn btn-primary my-4'>רכוש כאן</Link>
                : <Link to="/login" className='btn btn-primary my-4'>לרכישה יש להתחבר/להרשם קודם</Link>
                }
              </div>
            </article>

            <article className={classPrice + " order-md-0 order-2"}>
              <div className="box p-2 border my-md-2">
                <h2 className='display-4'>עסקי</h2>
                <h3 className='display-3 text-info'>{prices_ar[2].price} ₪</h3>
                <h3>מנוי שנתי</h3>
                <ul className='text-end'>
                  <li>חשבון נתמך עד 2 מנויים</li>
                  <li>בכל שבועיים סרטונים חדשים</li>
                  <li>כל הסרטונים פתוחים לצפייה</li>
                  <li>חוברות לימוד כתובות</li>
                  <li>קבצי קוד מסרטונים נתמכים</li>
                </ul>

                {info.login ? 
                <Link to="/pay/2" className='btn btn-primary my-4'>רכוש כאן</Link>
                : <Link to="/login" className='btn btn-primary my-4'>לרכישה יש להתחבר/להרשם קודם</Link>
                }
              </div>
            </article>
          </div>
          <div>
            <a href="https://monkeys.co.il/terms/" className='text-light h5' target="_blank">
              <p className='text-center'>לפני רכישה יש לקרוא את תקנון מאנקיס, לתקנון לחץ כאן</p>
            </a>
          </div>
        </article>
      </div>
    </div>
  )
}

export default Premium