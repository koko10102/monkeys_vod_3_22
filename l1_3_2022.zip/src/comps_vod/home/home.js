import React from 'react';


import CoursesList from './coursesList';
import "./home.css"
import Strip from './strip';

function Home(props){



  return(
    <main className='home'>
        <Strip />
        <CoursesList />
    </main> 
  )
}

export default Home