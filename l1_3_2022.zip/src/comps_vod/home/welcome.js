import React,{useContext} from 'react';
import { Link, useNavigate } from 'react-router-dom';
import AuthComp from '../authComp';
import { AppContext } from '../context/context';

function Welcome(props) {

  let {  info } = useContext(AppContext);
  let nav = useNavigate();
  if(info.paid){
    nav("/welcome-back")
  }
  return (
    <div className='container-fluid welcome_out'>
      <AuthComp />
    <div style={{backgroundImage:`url(/images/welcome.png)`, minHeight: "85vh"}} className='d-flex align-items-center container welcome' >
      <article className='w-100'>
          <h1 className='my-4'>ברוכים הבאים לMONKEYS PASS </h1>
        <div className="row">
          <div className="col-md-6">
            <ul>
              <li>
              התמקצע במקצוע ה FULLSTACK מהמדריכים הטובים ביותר בשוק
              </li>
              <li>תחזור מאותה נקודה בה הפסקת בדיוק</li>
              <li>עשרות קורסים ומאות סרטוני הדרכה שתוכל לצפות מכל מקום</li>
              <li>קורסים שמסודרים בדרגת קושי ומידע על ידע מקדים לכל קורס שתמיד תוכל להשלים בקורסים אצלנו</li>
            </ul>
            <button className='btn btn-info shadow'>הרשם לפרימיום</button>
            <Link to="/courses_vod"> 
            <button className='btn btn-dark me-2 shadow'>צפה בקורסים שלנו</button>
            </Link>
          </div>
          <div className="col-md-6"></div>
        </div>
      </article>
    </div>
    </div>
  )
}

export default Welcome