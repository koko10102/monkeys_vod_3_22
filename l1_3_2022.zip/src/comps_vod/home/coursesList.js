import React from 'react';
import { Link } from 'react-router-dom';

function CoursesList(props) {
  return (
    <div className='container-fluid courses'>
      <div className='container'>
        <h2 className='display-6 text-center mt-5' style={{fontWeight:"400"}}>
          קורסים שווים שנמצאים במנוי של MONKEYS PASS
        </h2>
        <h2 className='display-6 text-center mb-4'>מעל 15 קורסים ומעל 200 סרטונים בעברית במנוי אחד !</h2>
        <div className="row">
          <div className="col-md-4 p-2">
            <div className="box_course text-white" style={{ background: "black" }}>
              <div className="box_pic" style={{ backgroundImage: "url(/images/course4_react.jpg)" }}>
              <img src="/images/course4_react.jpg" alt="קורס REACT" className="w-100 d-block d-md-none" />
              </div>
              <h3>React js Hooks</h3>
              <p className='p-2'>קורס מעודכן לשנת 2022 הכולל בתוכו את רידקס וספריות צד לקוח פופלריות נוספות
              </p>
              <Link to="/player/880">סרטוני הקורס</Link>
            </div>

          </div>
          {/* end box */}
          <div className="col-md-4 p-2">
            <div className="box_course text-white" style={{ background: "black" }}>
              <div className="box_pic" style={{ backgroundImage: "url(/images/course3_node.jpg)" }}>
              <img src="/images/course3_node.jpg" alt="קורס NODEJS" className="w-100 d-block d-md-none" />
              </div>
              <h3>NODEJS + EXPRESS</h3>
              <p className='p-2'>קורס מקיף על צד שרת שכל מפתח FULLSTACK חייב להכיר בשוק העבודה</p>
              <Link to="/player/900">סרטוני הקורס</Link>
            </div>
          </div>
          {/* end box */}
          <div className="col-md-4 p-2">
            <div className="box_course text-white" style={{ background: "black" }}>
              <div className="box_pic" style={{ backgroundImage: "url(/images/course1.jpg)" }}>
                <img src="/images/course1.jpg" alt="קורס JS תרגול" className="w-100 d-block d-md-none" />
              </div>
              <h3>JS - מתרגלים ביחד</h3>
              <p className='p-2'>עשרות תרגילים שבחלקם הגדול נפתור
                יחד, בכל שבוע יתווספו תרגולים נוספים</p>
              <Link to="/player/991">סרטוני הקורס</Link>
            </div>
          </div>
          {/* end box */}
        </div>
        <div className='text-center my-5'>
          <Link to="/courses_vod/#" className='display-6 text-center btn btn-dark' style={{ fontSize: "2em" }}>לרשימת הקורסים </Link>
        </div>
        <h2 className='display-6 text-center my-5'>
          הרשמו עוד היום והכינו את עצמכם לשוק העבודה/פרילנס

        </h2>
        <div className='text-center'>
          <Link to="/premium#" className='display-6 text-center btn btn-info px-5' style={{ fontSize: "2em" }}>להרשמה לחצו כאן</Link>
        </div>
      </div>
    </div>
  )
}

export default CoursesList