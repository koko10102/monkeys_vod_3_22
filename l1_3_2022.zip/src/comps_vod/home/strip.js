import React from 'react';
import { Link } from 'react-router-dom';

function Strip(props) {
  return (
    <div className='strip container-fluid home' style={{ backgroundImage: "url(/images/cover_home2_light.jpg)" }}>
      <div className="container">
        <div className="row align-items-center">
          <div className="col-md-6" >
            <div>
              <h1 className='text-md-end text-center mt-5 mt-md-0'>המנוי שיכניס אותך לשוק העבודה בהיי טק</h1>
              <h4 className='my-4 mx-auto col-9 col-md-12'>מאנקיס פרימיום - המטרה שלנו היא ללמד אותך שלב אחר שלב את כל מה שתצטרך
                ומעבר בשביל להכנס לשוק העבודה בעולם ה FullStack
              </h4>
              <div className='text-center text-md-end'>
                <Link to="/courses_vod" className='btn btn-light px-4'>צפו ברשימת הקורסים שלנו</Link>
                <Link to="/premium" className='btn btn-info me-2 px-4'>מנוי הפרימיום</Link>
              </div>
            </div>
          </div>
          <div className="col-md-6 text-dark">
            <div className="bg-white rounded col-11 me-auto  my-card mx-auto  mx-md-0 me-md-auto my-4 my-md-0" >
              <div className='bg-card rounded' style={{ backgroundImage: "url(/images/cover_home2.jpg)" }}></div>
              <div className="card-body">
                <h5 className="card-title">מנוי פרימיום לכל הקורסים</h5>
                <p className="card-text">הרשם וקבל את MONKEYS PASS מנוי הכולל את כל הקורסים של מאנקיס במקום אחד וכל חודש סרטוני הדרכה חדשים מהתעשיה</p>

              </div>
            </div>
          </div>
        </div>

      </div>
    </div>
  )
}

export default Strip