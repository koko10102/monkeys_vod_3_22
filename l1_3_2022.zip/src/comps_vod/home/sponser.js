import React from 'react';

function Sponser(props){
  return(
    <div>Sponser work</div> 
  )
}

export default Sponser