import React, { useEffect, useState } from 'react';
import { Outlet } from 'react-router-dom';
import Footer from './footer';
import Header from './header';
import { AppContext } from "./context/context"
import {authUser} from "../services/auth"
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
// import Home from './home/home';
// import AppPlayer from './player/appPlayer';

function AppVod(props) {
  let [info, setInfo] = useState({ name: "guest", login: false, paid: false })

  const updateInfo = (_obj) => {
    setInfo({ ...info, ..._obj })
  }

  useEffect(() => {
    // check if paid
    checkIfPaid();
  }, []);

  const checkIfPaid = async() => {
    if(localStorage["tok_monkeys"]){
      authUser()
      .then(data => {
        if(data.role == "paid" || data.role == "admin"){
          updateInfo({paid:true,login: true});
        }
      })
    }
  }

  return (
    <AppContext.Provider value={{ info, updateInfo  }}>
      <React.Fragment>
        <Header />
        <Outlet />
        {/* <AppPlayer /> */}
        {/* <Home /> */}
        <Footer />
        <ToastContainer
          position="top-left" autoClose={5000} hideProgressBar={false}
          newestOnTop={false} closeOnClick rtl={true} pauseOnFocusLoss draggable pauseOnHover
        />
      </React.Fragment>
    </AppContext.Provider>
  )
}

export default AppVod