import React from 'react';
import { useNavigate } from 'react-router-dom';
import {toast} from "react-toastify"

function VideoBtnItem(props) {
  let nav = useNavigate()
  // אם פרי שקר וגם פייד שקר יוצג באפור ולא יהיה ניתן ללחיצה
  // אם לוחצים יפתח פופ אפ שיציג הרשמה בתשלום

  let item = props.item;
  const changeVid = () => {
    // alert(item.url_video)
    console.log(item.url_video)
    if (item.video_company === "vimeo") {

      let code = item.url_video.substring(item.url_video.indexOf(".com/") + 5, 99);
      props.changeVideo(code, "vimeo", item._id, item)
      
      // NAV -> http://localhost:3000/player/880/hljr2r
      // course_id/short_id 
      // alert(st)
    }
    else if (item.video_company === "youtube") {
      let andIndex = (item.url_video.indexOf("&") > -1) ? item.url_video.indexOf("&") : 99;
      // console.log(andIndex)
      let vIndex = item.url_video.indexOf("watch?v=") + 8
      let code = item.url_video.substring(vIndex, andIndex);
      console.log(code)
      props.changeVideo(code, "youtube", item._id, item)
      // alert(st)
    }
    nav(`/player/${item.course_id}/${item.short_id}`);
  }

  const whatIconShow = () => {
    // <i class="fa fa-check-square-o ms-2" aria-hidden="true"></i>
    // <i class="fa fa-square-o ms-2" aria-hidden="true"></i>

    if (item.play) {
      return (<i className="fa fa-caret-square-o-left ms-2" aria-hidden="true"></i>)
    }
    else if (item.watched) {
      return (<i className="fa fa-check-square-o ms-2" aria-hidden="true"></i>)
    }
    return (<i className="fa fa-square-o ms-2" aria-hidden="true"></i>)
  }

// בודק אם המשתמש יכול לצפות בוידיאו או לא
  const videoFree = () => {
    if ((!item.free && item.paid) || item.free) {
      // rgb(243, 243, 243) -> צבע תכלת
      return (<div onClick={changeVid} style={{ background: item.play ? "rgb(177, 213, 226)" : "" }} className="p-3 video_bar pe-4" >
        {whatIconShow()}
        {item.counter + 1}. {item.title}
      </div>)
    }
    else {
      return (<div onClick={showMessageBuySub}  style={{ background: item.play ? "rgb(177, 213, 226)" : "", color:"silver" }} className="p-3 video_bar pe-4" >
       <i className="fa fa-lock ms-2" aria-hidden="true"></i>
        {item.counter + 1}. {item.title}
      </div>)
    }
  }

  const showMessageBuySub = () => {
    toast.error(`סרטון זה פתוח לצפייה למנויי פרימיום בתשלום בלבד, לחץ כאן להמשך`, {
      position: "top-left",
      autoClose: 5000,
      hideProgressBar: false,
      closeOnClick: true,
      pauseOnHover: true,
      draggable: true,
      progress: undefined,
      theme:"colored",
      onClick:testAlert
      });
  }

  const testAlert = () => {
    nav("/premium")
    // alert("test")
  }
  // בודק םא נושא או סרטון ברשימה
  return (
    <React.Fragment  >
      {item.subject ?
        <div className="border p-3 py-2 subject_bar ">
          <strong> פרק {item.counter + 1}: {item.title} </strong>
        </div> : videoFree()
      }
    </React.Fragment>
  )
}

export default VideoBtnItem