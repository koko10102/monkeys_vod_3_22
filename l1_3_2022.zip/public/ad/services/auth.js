import { API_URL, doApiGet } from "./apiService.js";

// פונקציה שבודקת אם למשתמש יש טוקן
// נפעיל את הפונקציה בהתחלה של כל עמוד שבו אנחנו
// יודעים שהוא חייב להיות מחובר
export const authUser = async() => {
  let url = API_URL+"/users/authUser";
  // משתמש בפונקציה של הסרבס ולא בפצטץ' כדי לחסוך
  // לנו כתיבת שורות קוד עם שיגור פטצ עם טוקן
  let data = await doApiGet(url) 
  if(data.status != "ok"){
    alert("You need login again to be here");
    window.location.href = "login.html";
  }
}