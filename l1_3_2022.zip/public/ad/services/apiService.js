// export const API_URL = "http://localhost:3001"
export const API_URL = "https://2monkeys.co.il"

export const doApiGet = async (_url) => {
  let resp = await fetch(_url, {
    method: "GET",
    headers: {
      "x-api-key": localStorage["tok"],
      'content-type': "application/json"
    }
  })
  let data = await resp.json();
  // פונקציה שהיא אסינק אוטומטית מחזירה את המידע כפרומיס
  return data;
}


export const doApiMethod = async (_url, _method, _body) => {
  try {
    let resp = await fetch(_url, {
      method: _method,
      body: JSON.stringify(_body),
      headers: {
        "x-api-key": localStorage["tok"],
        'content-type': "application/json"
      }
    })
    let data = await resp.json();
    // פונקציה שהיא אסינק אוטומטית מחזירה את המידע כפרומיס
    return data;
  }
  catch (err) {
    console.log(err.response);
    return err;
  }
}