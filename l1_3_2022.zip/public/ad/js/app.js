import Dnd from "./dnd.js";

let names_ar = ["koko a","moshe b","berry c","grizzly d"];

window.onload = () => {
  // declareEvents()
  Dnd.declareFunc1(doSomeThing)
  Dnd.declareFunc2(swap)
  createNames();
}

const doSomeThing = (_e1,_e2) => {
  document.body.style.background = "silver";
  // console.log(_e1,_e2)
}

const swap = (_e1,_e2) => {
  document.body.style.background = "white";
  swapCellsByIndex(_e1.ariaSort,_e2.ariaSort,names_ar);
  createNames();
  // console.log(_e1,_e2)
}
 
const createNames = () => {
  document.querySelector(".container").innerHTML = "";
  names_ar.forEach((item,i) => {
    let elem = document.createElement("div");
    elem.className = "box";
    elem.myData = "myData";
    elem.ariaSort = i;
    elem.innerHTML = item;
    elem.dataset.dnd = item
    document.querySelector(".container").append(elem);
    Dnd.declareDragEvents(elem)
    
  })
}

const declareEvents = () => {
  let boxes_ar = document.querySelectorAll(".box");
  boxes_ar.forEach(elem => {
    elem.addEventListener("drop", Dnd.drop);
    elem.addEventListener("dragover", Dnd.dragOver);
    elem.addEventListener("dragstart", Dnd.dragInStart);
    elem.draggable = "true";

  })
}

const swapCellsByIndex = (_a,_b,_ar) => {
  let old = _ar[_a];
  _ar.splice(_a,1);
  _ar.splice(_b,0,old)
  // _ar[_a] = _ar[_b];
  // _ar[_b] = old;
  return _ar;
}