class Dnd {
  // הנגרר
  static elem1;
  // משוחרר עליו
  static elem2;
  // call when drag start
  static func1 = () => {};
  // call when drop on something
  static func2 = () => {};

  static dragOver(ev){
    ev.preventDefault();
  }

  static declareFunc1(_func1) {
    Dnd.func1 = _func1;
  }

  static declareFunc2(_func2) {
    Dnd.func2 = _func2;
  }
 
  static dragInStart(ev){
    // let elemData = ev.target.dataset["dnd"]
    // console.log(elemData, ev.target.ariaSort)
    // ev.dataTransfer.setData("elemData", elemData);
    // מעדכן מי הנגרר
    Dnd.elem1 = ev.target
    Dnd.func1(Dnd.elem1,Dnd.elem2);
  }

  static drop(ev){
    ev.preventDefault();
    // let data = ev.dataTransfer.getData("elemData");
    // console.log(data);
    // console.log(ev.target.dataset["dnd"])
    // מעדכן מי המשוחרר עליו
    Dnd.elem2 = ev.target;
    // console.log(Dnd.elem1,Dnd.elem2)
    Dnd.func2(Dnd.elem1,Dnd.elem2);
  }

  // במקום לכתוב כל פעם מחדש נותנים לאלמנט שנרצה שיהיה גריר
  static declareDragEvents(_elem){
    _elem.addEventListener("drop", Dnd.drop);
    _elem.addEventListener("dragover", Dnd.dragOver);
    _elem.addEventListener("dragstart", Dnd.dragInStart);
    _elem.draggable = "true";
  }
}

export default Dnd;