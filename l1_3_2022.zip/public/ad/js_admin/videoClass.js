import Dnd from "../services/dnd.js";
import { API_URL,  doApiMethod } from "../services/apiService.js";
import { showEditVideo } from "./editVideo.js";

class Video {
  constructor(_parent, _item, _doApi,_ChangeVidToYellow) {
    this.parent = _parent;
    this.title = _item.title;
    this.short_id = _item.short_id;
    this.info = _item.info;
    this.subject = _item.subject; // אם נושא או וידיאו
    this._id = _item._id;
    this.video_company = _item.video_company
    this.secs = _item.secs;
    this.url_video = _item.url_video
    this.doApi = _doApi //פונקציה
    this.course_id = _item.course_id
    this.free = _item.free;
    this.ChangeVidToYellow = _ChangeVidToYellow // פונקציה לסימון מי שנלחץ עליו
  }

  render() {
    let div = document.createElement("div");
    this.div = div;
    div.className = "box p-2 border text-end";
    div.style.background = "#f9f9f9"
    if (this.subject == true) {
      div.className = "box p-2 border bg-dark text-end text-light"
    }
    div.style.cursor = "pointer"
    div.style.direction = "rtl"
    document.querySelector(this.parent).append(div);
    if(this.free == true){
      div.innerHTML += '<button title="פתוח לכולם" class="badge bg-success float-start">f</button>'
    }
    div.innerHTML += `<button title="מחק" class="badge bg-danger float-start del_btn">X</button>`
    div.innerHTML += `<button title="עריכה" class="badge bg-info float-start edit_btn">ע</button>`
    div.innerHTML += `${this.title}`;
    
    // div.addEventListener("dragstart",Dnd.dragInStart)
    Dnd.declareDragEvents(div);
    div.querySelector(".del_btn").addEventListener("click", () => {
      // alert("x");
      div.style.backgroundColor = "orange"
      setTimeout(() => {
        if (confirm("Are you sure?")) {
          this.deleteVid()
        }
        else{
          div.style.backgroundColor = "transparent"
        }

      },100)
    })
    div.querySelector(".edit_btn").addEventListener("click", () => {
      showEditVideo(this);
      this.ChangeVidToYellow(this._id)
    })
    div.addEventListener("dblclick" , () => {
      showEditVideo(this);
      this.ChangeVidToYellow(this._id)
    })
  }

  deleteVid() {
    let url = API_URL + "/videos/" + this._id;
    doApiMethod(url, "DELETE", {})
      .then(data => {

        // alert("del")
        this.doApi();
      })
  }
}

export default Video;