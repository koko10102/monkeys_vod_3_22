import { API_URL, doApiMethod } from "../services/apiService.js";

class CourseTr{
  constructor(_parent,_item,_updatePosCourse){
    this.parent = _parent;
    this.title = _item.title;
    this.author = _item.author;
    this.author = this.author.replaceAll("<","")
    this.author = this.author.replaceAll(">","")
    this.price = _item.price;
    this.short_id = _item.short_id;
    this.position = _item.position;
    this.id = _item._id;
    this.img_url = _item.img_url;
    this.skill_needed = _item.skill_needed;
    this.updatePosCourse = _updatePosCourse;
    this.render();
  }

  render(){
    let tr = document.createElement("tr");
    document.querySelector(this.parent).append(tr);
    
    tr.innerHTML += `
    <td>${this.short_id}</td>
    <td>
      <button class="minus_btn badge bg-warning">-</button>
      ${this.position}
      <button class="plus_btn badge bg-dark">+</button>
    </td>
    <td title="${this.title}" style="direction:rtl;">
    <a class="btn btn-light" href="videosList.html?course=${this.short_id}">
    ${this.title.substr(0,40)}...
    </a>
    <img src="${this.img_url}" height="40" >
    </td>
    <td>${this.price}</td>
    <td title="${this.author}">${this.author.substr(0,20)}...</td>
    <td>
      <button class="btn btn-danger btn_del">מחק</button>
      <button class="btn btn-info btn_edit">ערוך</button>
    </td>
    `

    // for position changes
    let btn_plus = tr.querySelector(".plus_btn")
    let btn_minus = tr.querySelector(".minus_btn")

    btn_plus.addEventListener("click", () => {
      this.updatePosCourse(this, this.position+1);
    })
    btn_minus.addEventListener("click", () => {
      if(this.position == 0){this.position = 1};
      this.updatePosCourse(this, this.position-1);
    })


    let btn_del = tr.querySelector(".btn_del");
    btn_del.addEventListener("click", () => {
      if(confirm("האם אתה בטוח שאתה רוצה למחוק את הקורס מהמערכת?")){
        this.deleteCourse()
      }
    })

    let btn_edit = tr.querySelector(".btn_edit");
    btn_edit.addEventListener("click", () => {
      // alert(this.id);
      window.location.href = "edit_course.html?id="+this.id;
    })
  }

  deleteCourse(){
    let url = API_URL+"/courses/"+this.id;
    doApiMethod(url,"DELETE",{})
    .then(data => {
      window.location.reload();
    })
  }
}

export default CourseTr;