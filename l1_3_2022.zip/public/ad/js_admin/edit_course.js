
import { API_URL, doApiGet, doApiMethod } from "../services/apiService.js";
import { authUser } from "../services/auth.js"


let $$ = document.querySelector.bind(document);
let id
let short_id
window.onload = () => {
  authUser();
  doApi();
  declareEvents();
}

const doApi = async() => {
  const urlParams = new URLSearchParams(window.location.search);
  id = urlParams.get("id");
  if(id){
    let url = API_URL+"/courses/single/"+id;
    let data = await doApiGet(url);
    console.log(data)
    $$("#id_title").value = data.title;
    $$("#id_info").value = data.info;
    $$("#id_author").value = data.author;
    $$("#id_skill_needed").value = data.skill_needed;
    $$("#id_price").value = data.price;
    $$("#id_position").value = data.position;
    $$("#id_img_url").value = data.img_url;
    $$("#id_category").value = data.category;
    $$("#id_link_outside").value = data.link_outside;
    short_id = data.short_id
    $('textarea').trumbowyg();
  }
}

const declareEvents = () => {
  $$("#id_form").addEventListener("submit", (e) => {
    e.preventDefault();
    // doApiMethod -> Put 
    console.log("Aa");
    let body = {
      title:$$("#id_title").value,
      info:$$("#id_info").value,
      author:$$("#id_author").value,
      skill_needed:$$("#id_skill_needed").value,
      price:$$("#id_price").value,
      position:$$("#id_position").value,
      img_url:$$("#id_img_url").value,
      category:$$("#id_category").value,
      link_outside:$$("#id_link_outside").value,
      short_id:short_id
    }
    let url = API_URL+"/courses/"+id;
    doApiMethod(url,"PUT",body)
    .then(data => {
      console.log(data)
      if(data[0]){
        alert(data[0].message)
      }
      if(data.modifiedCount){
        alert("Update success")

      }
    }) 
    console.log(body);
  })
}