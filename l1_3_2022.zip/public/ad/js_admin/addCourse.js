
import { API_URL, doApiGet, doApiMethod } from "../services/apiService.js";
import { authUser } from "../services/auth.js"


let $ = document.querySelector.bind(document);
let id
let short_id
window.onload = () => {
  authUser();
  
  declareEvents();
}


const declareEvents = () => {
  $("#id_form").addEventListener("submit", (e) => {
    e.preventDefault();
    // doApiMethod -> Put 
    console.log("Aa");
    let body = {
      title:$("#id_title").value,
      info:$("#id_info").value,
      author:$("#id_author").value,
      skill_needed:$("#id_skill_needed").value,
      price:$("#id_price").value,
      position:$("#id_position").value,
      img_url:$("#id_img_url").value,
      category:$("#id_category").value,
      short_id:$("#id_short_id").value,
      link_outside:$("#id_link_outside").value
    }
    let url = API_URL+"/courses/";
    doApiMethod(url,"POST",body)
    .then(data => {
      if(data.msg){
        alert("קוד מקוצר בחר קוד אחר- הגיל שלך + מספר הדקות")
      }
      if(data._id){
        alert("קורס נוסף בהצלחה")
        window.location.href = "myCourses.html"

      }
      else{
        alert("יש בעיה נסה מאוחר יותר שוב")
      }
    }) 
    console.log(body);
  })
}