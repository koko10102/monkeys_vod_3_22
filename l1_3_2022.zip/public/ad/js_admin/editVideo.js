import { API_URL, doApiMethod } from "../services/apiService.js";

let $ = document.querySelector.bind(document);

let id_title;
let id_info;
let id_url_video;
let id_video_company;
let id_short_id;
let id_secs;
let id_free; // אם חינמני
let vid_id; // האיי די של הוידיאו לעדכון
let course_id

// נקרא מהקלאס של VIDEOCLASS
export const showEditVideo = (_item) => {
  $("#id_form").style.display = "block";
  id_title = document.querySelector("#id_title")
  id_info = document.querySelector("#id_info")
  id_url_video = document.querySelector("#id_url_video")
  id_video_company = document.querySelector("#id_video_company")
  id_short_id = document.querySelector("#id_short_id")
  id_secs = document.querySelector("#id_secs")
  id_free = document.querySelector("#id_free")
  
  vid_id = _item._id;
  course_id = _item.course_id;

  id_title.value = _item.title;
  id_info.value = _item.info || "";
  document.querySelector(".trumbowyg-editor").innerHTML = _item.info;
  // id_info.innerHTML = _item.info;
  id_url_video.value = _item.url_video || ""
  id_video_company.value = _item.video_company;

  id_short_id.value = _item.short_id;
  id_secs.value = _item.secs || 0;
  console.log(_item.free)
  id_free.value = String(_item.free) || "false"
}

export const formEditInit = (_doApi) => {
  $("#id_form").style.display = "none";

  $("#id_url_video").addEventListener("input" , () => {
    if($("#id_url_video").value.includes("youtube.")){
      $("#id_video_company").value = "youtube";
    }
    else{
      $("#id_video_company").value = "vimeo";
    }
  })

  $("#id_form").addEventListener("submit", (e) => {
    e.preventDefault();
    let body = {
      title:id_title.value,
      info:id_info.value,
      course_id:course_id,
      url_video:id_url_video.value,
      video_company:id_video_company.value,
      secs:id_secs.value,
      free:id_free.value
    }
    let url = API_URL+"/videos/"+vid_id;
    doApiMethod(url, "PUT", body)
    .then(data => {
      if(data.modifiedCount){
        alert("update success")
        _doApi();
      }
      else{
        alert("There problem try again later")
      }
      console.log(data);
    })
  })
}

