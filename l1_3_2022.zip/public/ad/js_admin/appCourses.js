import { API_URL, doApiGet, doApiMethod } from "../services/apiService.js";
import { authUser } from "../services/auth.js";
import CourseTr from "./courseTrClass.js";

window.onload = () => {
  // בדיקת אבטחה
  authUser();
  doApi();
}

const doApi = async () => {
  let url = API_URL + "/courses/myCourses/";
  let data = await doApiGet(url);
  console.log(data);
  // לייצר טבלה
  // לחיצה על קורס ייקח לכל השיעורים בתוכו 
  // ונבנה את המערכת של הדראג אנד דרופ
  createTable(data);
}

const createTable = (_ar) => {
  document.querySelector("#id_tbody").innerHTML = "";
  _ar.forEach(item => {
    let tr = new CourseTr("#id_tbody", item, updatePosCourse);
  })
}


// מעדכן מיקום הקורס
const updatePosCourse = async (_item, _pos) => {
  let objBody = {
    title: _item.title,
    author: _item.author,
    skill_needed: _item.skill_needed,
    short_id: _item.short_id,
    position: _pos
  }
  let url = API_URL + "/courses/" + _item.id;
  try {
    let data = await doApiMethod(url, "PUT", objBody)
    if (data.modifiedCount) {
      doApi();
    }
  }
  catch (err) {
    console.log(err);
  }
}