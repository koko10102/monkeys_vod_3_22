import { API_URL, doApiGet } from "../services/apiService.js";
import { authUser } from "../services/auth.js";
// import CourseTr from "./courseTrClass.js";
import UserTr from "./userTr.js";

let page

window.onload = () => {
  // בדיקת אבטחה
  authUser();
  doApi();
  createPageLinks();
}

const createPageLinks = () => {
  for(let i = 0 ; i < 20 ; i++){
    document.querySelector(".page_links").innerHTML += `
      <a href="usersList.html?page=${i+1}">${i+1}</a> |
    `
  }
}

const doApi = async() => {
  const urlParams = new URLSearchParams(window.location.search);
 page = urlParams.get("page") || 1;

  let url = API_URL+"/users/list/?page="+page;
  let data = await doApiGet(url);
  console.log(data);
// לייצר טבלה
// לחיצה על קורס ייקח לכל השיעורים בתוכו 
// ונבנה את המערכת של הדראג אנד דרופ
  
  createTable(data);
}

const createTable = (_ar) => {
  document.querySelector("#id_tbody").innerHTML = "";
  _ar.forEach(item => {
    item.page = page;
    let tr = new UserTr("#id_tbody",item,doApi);
  })
}