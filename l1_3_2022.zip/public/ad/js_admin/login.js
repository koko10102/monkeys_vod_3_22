import { API_URL, doApiMethod } from "../services/apiService.js";


window.onload = () => {
  declareEvents();
}

const declareEvents = () => {
  let id_form = document.querySelector("#id_form");
  id_form.addEventListener("submit", (e) => {
    // למנוע את הברירת מחדל של שיגור טופס
    e.preventDefault();
    let id_email = document.querySelector("#id_email").value;
    let id_password = document.querySelector("#id_password").value;
    if (id_email.length < 4 || !id_email.includes("@") || !id_email.includes(".")) {
      alert("Email invalid");
      return;
    }
    if (id_password.length < 3) {
      alert("Password worng!");
      return;
    }
    doApi();
  })
}

const doApi = async () => {
  let body = {
    email: document.querySelector("#id_email").value,
    password: document.querySelector("#id_password").value
  }

  let url = API_URL+"/users/login";
  try {

    let data = await doApiMethod(url, "POST", body)
    if (data.token) {
      console.log(data);
      localStorage.setItem("tok", data.token)
      // ישוגר ל מיי אינפו
      window.location.href = "myCourses.html";
    }
    else{
      alert("Email or password worng!");
    }
  }
  catch (err) {
    console.log(err);
    alert("Email or password worng!");
  }
}
