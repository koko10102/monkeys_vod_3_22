import { API_URL,doApiGet, doApiMethod } from "../services/apiService.js";
import { authUser } from "../services/auth.js";
import Dnd from "../services/dnd.js";
import { formEditInit } from "./editVideo.js";
import Video from "./videoClass.js";

let $ = document.querySelector.bind(document);
let vid_ar = [];
let div_vidBtn_ar = []
let course = {}
let id_course = ""
let first_time = true; // אם לקפוץ לתחתית

window.onload = () => {
  authUser();
  dndReady();
  doApi();
  declareEvents();
  formEditInit(doApi);
}

const declareEvents = () => {

  $("#add_subject_btn").addEventListener("click", () => {
    let body = {title:"נושא חדש", course_id:id_course,subject:true }
    let url = API_URL+"/videos/";
    doApiMethod(url,"POST",body)
    .then(data => {
      console.log(data);
      if(data._id){
        alert("הוספת נושא הצליחה!");
        doApi();
      }
      else{
        alert("there problem!");
      }
    })
  })
  
  $("#add_movie_btn").addEventListener("click", () => {
    let body = {title:"סרטון חדש", course_id:id_course}
    let url = API_URL+"/videos/";
    doApiMethod(url,"POST",body)
    .then(data => {
      console.log(data);
      if(data._id){
        alert("סרטון חדש נוסף");
        doApi();
      }
      else{
        alert("there problem!");
      }
    })
  })

  // שמירת סדר הסרטונים
  $("#save_btn").addEventListener("click", () => {
    let save_ar = []
    vid_ar.forEach(item => {
      save_ar.push(item.short_id)
    })
    let url = API_URL+"/courses/"+course._id;
    doApiMethod(url,"PATCH",{videos_sort:save_ar})
    .then(data => {
      if(data.modifiedCount){
        alert("שמירת סדר הסרטונים עודכן בהצלחה")
      }
      else{
        alert("ישנה תקלה או הסדר לא שונה , אנא נסה שנית מאוחר יותר")
      }
      // console.log(data);
    })
    // console.log(save_ar);
  })
}

const doApi = async () => {
  $("#id_list").innerHTML = "loading...";
  console.log("do api")
  const urlParams = new URLSearchParams(window.location.search);
  id_course = urlParams.get("course") || "992";
  if(id_course){
    let url = API_URL+"/videos/byCourse/"+id_course;
    let data = await doApiGet(url);
    // console.log(data);
    vid_ar = data;
    let url2 = API_URL+"/courses/single/"+id_course
    course = await doApiGet(url2)
    console.log("course",course.videos_sort);
    
    document.querySelector("#id_title1").innerHTML = course.title;
    //מסדר את הסרטונים ו 
    vid_ar = sortById(course.videos_sort, vid_ar);
    createDivs(vid_ar);
  }
}

const createDivs =  (_ar) => {
  div_vidBtn_ar = []
  $("#id_list").innerHTML = "";
  _ar.map((item,i) => {
    let vid = new Video("#id_list", item, doApi,ChangeVidToYellow);
    vid.render();
    vid.div.ariaSort = i;
    div_vidBtn_ar.push(vid);
  })
  if(!first_time){
    window.location.href = "#id_bottom"
    
  }
  first_time = false;
}

const ChangeVidToYellow = (_id) => {
  div_vidBtn_ar.forEach(item => {
    item.div.style.marginLeft = "0px";
    // item.div.style.transform = "translate(0,0)";
    if(item._id == _id){
      item.div.style.marginLeft = "-30px";
    }
  })
}

const dndReady = () => {
  Dnd.declareFunc1(divDown)
  Dnd.declareFunc2(swap)
}

const sortById = (sort_ar, _videos_ar) => {
  let newSort_ar = []
  _videos_ar.forEach((item, i) => {
    // console.log(item,sortid_ar[i])
    newSort_ar[sort_ar.indexOf(item.short_id)] = item;
  })
  return newSort_ar;
}

const divDown = (_e1,_e2) => {
  _e1.style.boxShadow = "-2px 1px 15px 5px #FF1212"
  _e1.style.zIndex = "99"
  // _e1.style.border = "orange"
}

const swap = (_e1,_e2) => {
  vid_ar = swapCellsByIndex(_e1.ariaSort,_e2.ariaSort,vid_ar);
  first_time = true;
  createDivs(vid_ar);
} 

const swapCellsByIndex = (_a,_b,_ar) => {
  let old = _ar[_a];
  _ar.splice(_a,1);
  _ar.splice(_b,0,old)
  return _ar;
}