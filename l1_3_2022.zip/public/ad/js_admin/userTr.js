import { API_URL, doApiMethod } from "../services/apiService.js";

class UserTr{
  static counter = 0;

  constructor(_parent,_item,_doApi){
    this.parent = _parent;
    this.name = _item.name;
    this.email = _item.email;
    this.date_paid_up_to = _item.date_paid_up_to;
    let date = _item.date_paid_up_to;
    date = date.replace("T"," ")
    this.date_paid_up_to = date.substring(0,date.indexOf(":")) + ":00"
    this.money_paid = _item.money_paid
    this.role = _item.role;
    this.id = _item._id;
    this.doApi = _doApi;
    this.page = _item.page
    this.render();
  }



  render(){
    let tr = document.createElement("tr");
    document.querySelector(this.parent).append(tr);
    UserTr.counter++;
    tr.innerHTML += `
    <td>${UserTr.counter + ((this.page-1) * 20 )}</td>
    <td title="${this.name}" style="direction:rtl;">
    <a class="btn btn-light add_month" href="#">
    ${this.name} 
    </a>
    </td>
    <td>${this.email}</td>
    <td><button class="btn_admin btn ${this.role != "user"  ? "btn-warning" : "btn-dark"}">${this.role}</button></td>
    <td>${this.date_paid_up_to}</td>
    <td>${this.money_paid}</td>
    
    <td>
      <button title="${this.id}" class="btn btn-danger btn_del">מחק</button>
   
    </td>
    `
    let add_btn = tr.querySelector(".add_month");
    add_btn.addEventListener("click" , () => {
      // alert("work");
      let months = prompt("enter number of months");
      let url = API_URL+"/users/user_paid?id="+this.id+"&money="+this.money_paid+"&month="+months;
      doApiMethod(url, "POST",{})
      .then(data => {
        console.log(data);
        if(data.modifiedCount){
          this.doApi();
        }
      })
    })

    let btn = tr.querySelector(".btn_admin");
    btn.addEventListener("click",() => {
      // alert(this.id);
      let url
      if(this.role == "user"){
      url  = API_URL+"/users/user_paid?id="+this.id;
      }
      else{
        url = API_URL+"/users/user_paid?paid=false&id="+this.id;

      }
      doApiMethod(url, "POST",{})
      .then(data => {
        console.log(data);
        if(data.modifiedCount){
          this.doApi();
        }
      })
    })



    
  }

 
}

export default UserTr;